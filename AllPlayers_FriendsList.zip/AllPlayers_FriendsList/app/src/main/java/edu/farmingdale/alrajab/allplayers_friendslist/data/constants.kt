package edu.farmingdale.alrajab.allplayers_friendslist.data

const val NODE_CONTACTS = "contacts"